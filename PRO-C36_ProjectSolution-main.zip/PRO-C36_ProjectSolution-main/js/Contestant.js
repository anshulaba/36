class Contestant {
  constructor(){
   
  }

  
}
